package christmas.hat;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

/** Toggle controller. Renderer attachment is not yet wired in this starter project. */
public final class SantaHatClient implements ClientModInitializer {
    public static boolean hatEnabled = true;
    public static final HatSpring SPRING = new HatSpring();
    @Override public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
            net.minecraft.resources.Identifier.fromNamespaceAndPath("realisticsantahat", "cosmetics"));
        KeyMapping toggle = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.realisticsantahat.toggle", InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_H, category));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggle.consumeClick()) {
                hatEnabled = !hatEnabled;
                if (client.player != null) client.player.displayClientMessage(
                    Component.literal("Santa hat: " + (hatEnabled ? "ON" : "OFF")), true);
            }
            if (client.player != null) {
                double speed = client.player.getDeltaMovement().horizontalDistance();
                SPRING.tick(speed, !client.player.onGround());
            }
        });
    }
}
