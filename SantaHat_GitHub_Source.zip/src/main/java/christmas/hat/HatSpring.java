package christmas.hat;
/** Damped spring for the drooping tip/pom-pom. Values are radians. */
public final class HatSpring {
    public float angle = 0f;
    public float velocity = 0f;
    public void tick(double horizontalSpeed, boolean airborne) {
        float target = (float) Math.min(0.35, horizontalSpeed * 0.65) + (airborne ? -0.13f : 0f);
        float force = (target - angle) * 0.16f;
        velocity = (velocity + force) * 0.77f;
        angle += velocity;
    }
}
