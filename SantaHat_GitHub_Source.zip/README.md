# Realistic Santa Hat — Fabric 26.2 source starter

**Status: unfinished mod source, NOT an installable JAR.**

Included:
- Client-side H keybind (Santa hat ON/OFF), remappable in Controls.
- Damped spring simulation for the drooping tip and pom-pom.
- 3D model design reference in `design/santa_hat_model.json`.

**Still needed before this is a working cosmetic:**
- Implement and register a Minecraft 26.2-compatible player render layer / render-state integration.
- Wire the spring angle into the hat-tip and pom-pom transforms.
- Compile and test using JDK 25, Gradle 9.5.1, Fabric Loom 1.17 and matching Fabric API.

The source is provided so the art, toggle logic and animation can be developed further. **Do not place this ZIP in your mods folder.**

The Christmas resource pack is separately installable as a ZIP.
